'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { 
  Upload, 
  FileText, 
  Youtube, 
  Brain, 
  BookOpen, 
  FileQuestion, 
  ListChecks,
  Sparkles,
  ArrowLeft,
  Loader2
} from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'
import { useStudyStore } from '@/store/useStudyStore'
import type { StudyItemType, StudyItem } from '@/lib/types'

const outputTypes = [
  { id: 'mindmap' as StudyItemType, icon: Brain, label: 'Mind Map', description: 'Visual topic overview' },
  { id: 'flashcard' as StudyItemType, icon: BookOpen, label: 'Flashcards', description: 'Q&A study cards' },
  { id: 'quiz' as StudyItemType, icon: FileQuestion, label: 'Quiz', description: 'Test your knowledge' },
  { id: 'summary' as StudyItemType, icon: ListChecks, label: 'Summary', description: 'Key bullet points' },
]

export default function CreatePage() {
  const router = useRouter()
  const { addItem, decrementCredits, user, setIsGenerating } = useStudyStore()
  const [content, setContent] = useState('')
  const [title, setTitle] = useState('')
  const [youtubeUrl, setYoutubeUrl] = useState('')
  const [selectedType, setSelectedType] = useState<StudyItemType>('mindmap')
  const [isLoading, setIsLoading] = useState(false)
  const [isDragging, setIsDragging] = useState(false)

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    
    const files = e.dataTransfer.files
    if (files.length > 0) {
      const file = files[0]
      if (file.type === 'text/plain') {
        const reader = new FileReader()
        reader.onload = (e) => {
          setContent(e.target?.result as string)
        }
        reader.readAsText(file)
      } else {
        toast.error('Only text files are supported for now')
      }
    }
  }, [])

  const handleGenerate = async () => {
    if (!content.trim() && !youtubeUrl.trim()) {
      toast.error('Please enter some content to generate from')
      return
    }

    if (user && user.credits <= 0) {
      toast.error('No credits remaining. Please upgrade your plan.')
      return
    }

    setIsLoading(true)
    setIsGenerating(true)

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: content || `YouTube video: ${youtubeUrl}`,
          type: selectedType,
          title: title || undefined,
        }),
      })

      const data = await response.json()

      if (data.success && data.data) {
        addItem(data.data as StudyItem)
        decrementCredits()
        toast.success('Study material created!')
        
        // Navigate to the appropriate viewer
        const routes: Record<StudyItemType, string> = {
          mindmap: '/map',
          flashcard: '/flashcards',
          quiz: '/quiz',
          summary: '/dashboard',
        }
        router.push(`${routes[selectedType]}/${data.data.id}`)
      } else {
        toast.error(data.error || 'Failed to generate content')
      }
    } catch {
      toast.error('Something went wrong. Please try again.')
    } finally {
      setIsLoading(false)
      setIsGenerating(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link href="/dashboard" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold text-foreground">Create Study Material</h1>
          <p className="text-muted-foreground mt-2">Upload your content and let AI transform it</p>
        </div>

        <div className="space-y-8">
          {/* Title input */}
          <div className="space-y-2">
            <Label htmlFor="title">Title (optional)</Label>
            <Input
              id="title"
              placeholder="Give your study material a name..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="max-w-md"
            />
          </div>

          {/* Content input */}
          <div className="space-y-4">
            <Label>Content</Label>
            
            {/* Drop zone */}
            <motion.div
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={cn(
                'border-2 border-dashed rounded-xl p-8 text-center transition-colors',
                isDragging ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
              )}
            >
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                  <Upload className="w-8 h-8 text-primary" />
                </div>
                <p className="text-foreground font-medium mb-1">
                  Drop your file here or paste text below
                </p>
                <p className="text-sm text-muted-foreground">
                  Supports text files, or paste directly
                </p>
              </div>
            </motion.div>

            {/* Text input */}
            <Textarea
              placeholder="Paste your notes, article, or any text content here..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={8}
              className="resize-none"
            />

            {/* YouTube input */}
            <div className="flex items-center gap-4">
              <div className="flex-1 relative">
                <Youtube className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Or paste a YouTube URL..."
                  value={youtubeUrl}
                  onChange={(e) => setYoutubeUrl(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>

          {/* Output type selector */}
          <div className="space-y-4">
            <Label>Output Type</Label>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {outputTypes.map((type) => (
                <button
                  key={type.id}
                  onClick={() => setSelectedType(type.id)}
                  className={cn(
                    'flex flex-col items-center p-4 rounded-xl border-2 transition-all',
                    selectedType === type.id
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/30'
                  )}
                >
                  <div className={cn(
                    'w-12 h-12 rounded-xl flex items-center justify-center mb-3',
                    selectedType === type.id ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'
                  )}>
                    <type.icon className="w-6 h-6" />
                  </div>
                  <p className="font-medium text-foreground">{type.label}</p>
                  <p className="text-xs text-muted-foreground">{type.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Generate button */}
          <div className="flex items-center gap-4 pt-4">
            <Button
              size="lg"
              onClick={handleGenerate}
              disabled={isLoading || (!content.trim() && !youtubeUrl.trim())}
              className="bg-primary hover:bg-primary/90 gap-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Generate with AI
                </>
              )}
            </Button>
            <p className="text-sm text-muted-foreground">
              <FileText className="w-4 h-4 inline mr-1" />
              Uses 1 credit
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
