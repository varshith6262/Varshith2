'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { ArrowLeft, Search, Brain, BookOpen, FileQuestion, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

const subjects = ['All', 'Science', 'History', 'Math', 'Language', 'Business']

const templates = [
  {
    id: '1',
    title: 'Cell Biology Basics',
    subject: 'Science',
    description: 'Learn about cell structure, organelles, and functions',
    type: 'mindmap',
    icon: Brain,
  },
  {
    id: '2',
    title: 'World War II Timeline',
    subject: 'History',
    description: 'Key events and dates from 1939-1945',
    type: 'flashcard',
    icon: BookOpen,
  },
  {
    id: '3',
    title: 'Algebra Fundamentals',
    subject: 'Math',
    description: 'Basic algebraic concepts and formulas',
    type: 'quiz',
    icon: FileQuestion,
  },
  {
    id: '4',
    title: 'Spanish Vocabulary',
    subject: 'Language',
    description: 'Common Spanish words and phrases',
    type: 'flashcard',
    icon: BookOpen,
  },
  {
    id: '5',
    title: 'Marketing Principles',
    subject: 'Business',
    description: 'Core marketing concepts and strategies',
    type: 'summary',
    icon: FileText,
  },
  {
    id: '6',
    title: 'Periodic Table',
    subject: 'Science',
    description: 'Elements, atomic numbers, and properties',
    type: 'mindmap',
    icon: Brain,
  },
  {
    id: '7',
    title: 'French Revolution',
    subject: 'History',
    description: 'Causes, events, and outcomes',
    type: 'quiz',
    icon: FileQuestion,
  },
  {
    id: '8',
    title: 'Calculus Basics',
    subject: 'Math',
    description: 'Derivatives and integrals introduction',
    type: 'flashcard',
    icon: BookOpen,
  },
  {
    id: '9',
    title: 'Japanese Hiragana',
    subject: 'Language',
    description: 'Learn the Japanese hiragana characters',
    type: 'flashcard',
    icon: BookOpen,
  },
  {
    id: '10',
    title: 'Financial Statements',
    subject: 'Business',
    description: 'Balance sheets, income statements, cash flow',
    type: 'mindmap',
    icon: Brain,
  },
  {
    id: '11',
    title: 'Human Anatomy',
    subject: 'Science',
    description: 'Major body systems and organs',
    type: 'quiz',
    icon: FileQuestion,
  },
  {
    id: '12',
    title: 'Ancient Egypt',
    subject: 'History',
    description: 'Pharaohs, pyramids, and culture',
    type: 'summary',
    icon: FileText,
  },
]

const typeColors = {
  mindmap: 'bg-primary/10 text-primary',
  flashcard: 'bg-accent/20 text-accent-foreground',
  quiz: 'bg-primary/10 text-primary',
  summary: 'bg-accent/20 text-accent-foreground',
}

export default function TemplatesPage() {
  const [selectedSubject, setSelectedSubject] = useState('All')
  const [searchQuery, setSearchQuery] = useState('')

  const filteredTemplates = templates.filter(template => {
    const matchesSubject = selectedSubject === 'All' || template.subject === selectedSubject
    const matchesSearch = template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesSubject && matchesSearch
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4 mb-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Templates</h1>
              <p className="text-muted-foreground">Pre-built study materials to get you started</p>
            </div>
          </div>

          {/* Search and filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search templates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
              {subjects.map(subject => (
                <Button
                  key={subject}
                  variant={selectedSubject === subject ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedSubject(subject)}
                  className={cn(
                    'shrink-0',
                    selectedSubject === subject && 'bg-primary hover:bg-primary/90'
                  )}
                >
                  {subject}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </motion.header>

      {/* Templates grid */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredTemplates.map((template, index) => {
            const Icon = template.icon
            return (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <div className="group bg-card rounded-xl border border-border p-5 hover:border-primary/30 hover:shadow-lg transition-all duration-300">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform',
                      typeColors[template.type as keyof typeof typeColors]
                    )}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-medium px-2 py-1 rounded-full bg-muted text-muted-foreground">
                      {template.subject}
                    </span>
                  </div>

                  <h3 className="font-semibold text-foreground mb-1">{template.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{template.description}</p>

                  <Button size="sm" className="w-full bg-primary hover:bg-primary/90">
                    Use Template
                  </Button>
                </div>
              </motion.div>
            )
          })}
        </div>

        {filteredTemplates.length === 0 && (
          <div className="text-center py-20">
            <p className="text-muted-foreground">No templates found matching your criteria</p>
          </div>
        )}
      </main>
    </div>
  )
}
