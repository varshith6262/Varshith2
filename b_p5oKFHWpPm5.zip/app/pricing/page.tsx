'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Check, ArrowLeft, Brain } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { cn } from '@/lib/utils'

const plans = [
  {
    name: 'Free',
    price: 0,
    annualPrice: 0,
    description: 'Perfect for trying out LearnAI',
    features: [
      '50 AI generations per month',
      'Basic mind maps',
      'Flashcard creation',
      'Simple quizzes',
      'Community support',
    ],
    notIncluded: [
      'Advanced mind maps',
      'Export to PDF',
      'Team collaboration',
      'API access',
    ],
    credits: 50,
    cta: 'Get Started',
    highlighted: false,
  },
  {
    name: 'Basic',
    price: 9,
    annualPrice: 7,
    description: 'Great for regular students',
    features: [
      '500 AI generations per month',
      'Advanced mind maps',
      'Unlimited flashcards',
      'All quiz types',
      'Export to PDF',
      'Email support',
    ],
    notIncluded: [
      'Team collaboration',
      'API access',
    ],
    credits: 500,
    cta: 'Start Basic',
    highlighted: false,
  },
  {
    name: 'Pro',
    price: 19,
    annualPrice: 15,
    description: 'Best for power users',
    features: [
      'Unlimited AI generations',
      'Premium mind maps',
      'Unlimited flashcards',
      'All quiz types',
      'Export to all formats',
      'Priority support',
      'Team collaboration',
      'API access',
    ],
    notIncluded: [],
    credits: 'unlimited',
    cta: 'Start Pro',
    highlighted: true,
  },
]

const comparisonFeatures = [
  { name: 'AI Generations', free: '50/month', basic: '500/month', pro: 'Unlimited' },
  { name: 'Mind Maps', free: 'Basic', basic: 'Advanced', pro: 'Premium' },
  { name: 'Flashcards', free: 'Limited', basic: 'Unlimited', pro: 'Unlimited' },
  { name: 'Quiz Types', free: 'Basic', basic: 'All', pro: 'All' },
  { name: 'Export Formats', free: '-', basic: 'PDF', pro: 'All formats' },
  { name: 'Support', free: 'Community', basic: 'Email', pro: 'Priority' },
  { name: 'Team Collaboration', free: '-', basic: '-', pro: 'Yes' },
  { name: 'API Access', free: '-', basic: '-', pro: 'Yes' },
]

export default function PricingPage() {
  const [isAnnual, setIsAnnual] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <Brain className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-bold text-lg text-foreground">LearnAI</span>
            </Link>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/login">
              <Button variant="ghost" size="sm">Log in</Button>
            </Link>
            <Link href="/register">
              <Button size="sm" className="bg-primary hover:bg-primary/90">Get Started</Button>
            </Link>
          </div>
        </div>
      </motion.header>

      <main className="max-w-7xl mx-auto px-4 py-16">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Choose the plan that fits your learning needs. All plans include our core AI features.
          </p>

          {/* Toggle */}
          <div className="flex items-center justify-center gap-3">
            <span className={cn('text-sm', !isAnnual ? 'text-foreground font-medium' : 'text-muted-foreground')}>
              Monthly
            </span>
            <Switch checked={isAnnual} onCheckedChange={setIsAnnual} />
            <span className={cn('text-sm', isAnnual ? 'text-foreground font-medium' : 'text-muted-foreground')}>
              Annual
              <span className="ml-1.5 text-xs text-primary font-medium">Save 20%</span>
            </span>
          </div>
        </motion.div>

        {/* Pricing cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-20">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={cn(
                'relative bg-card rounded-2xl border p-6',
                plan.highlighted
                  ? 'border-primary shadow-xl shadow-primary/10 scale-[1.02]'
                  : 'border-border'
              )}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                  Most Popular
                </div>
              )}

              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-foreground mb-2">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
                <div className="flex items-end justify-center gap-1">
                  <span className="text-5xl font-bold text-foreground">
                    ${isAnnual ? plan.annualPrice : plan.price}
                  </span>
                  <span className="text-muted-foreground mb-2">/mo</span>
                </div>
                {isAnnual && plan.price > 0 && (
                  <p className="text-sm text-muted-foreground mt-1">
                    Billed annually (${plan.annualPrice * 12}/year)
                  </p>
                )}
              </div>

              <Link href="/register">
                <Button
                  className={cn(
                    'w-full mb-6',
                    plan.highlighted
                      ? 'bg-primary hover:bg-primary/90'
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                  )}
                >
                  {plan.cta}
                </Button>
              </Link>

              <div className="space-y-3">
                {plan.features.map((feature) => (
                  <div key={feature} className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary shrink-0" />
                    <span className="text-sm text-foreground">{feature}</span>
                  </div>
                ))}
                {plan.notIncluded.map((feature) => (
                  <div key={feature} className="flex items-center gap-2 opacity-50">
                    <div className="w-5 h-5 flex items-center justify-center shrink-0">
                      <div className="w-1 h-1 rounded-full bg-muted-foreground" />
                    </div>
                    <span className="text-sm text-muted-foreground">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Comparison table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <h2 className="text-2xl font-bold text-foreground text-center mb-8">
            Feature Comparison
          </h2>
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="text-left p-4 font-medium text-foreground">Feature</th>
                    <th className="text-center p-4 font-medium text-foreground">Free</th>
                    <th className="text-center p-4 font-medium text-foreground">Basic</th>
                    <th className="text-center p-4 font-medium text-primary">Pro</th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonFeatures.map((feature, index) => (
                    <tr key={feature.name} className={index < comparisonFeatures.length - 1 ? 'border-b border-border' : ''}>
                      <td className="p-4 text-foreground">{feature.name}</td>
                      <td className="p-4 text-center text-muted-foreground">{feature.free}</td>
                      <td className="p-4 text-center text-muted-foreground">{feature.basic}</td>
                      <td className="p-4 text-center text-primary font-medium">{feature.pro}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>

        {/* FAQ or CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="text-center mt-16"
        >
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Still have questions?
          </h2>
          <p className="text-muted-foreground mb-6">
            Contact our team for more information about our plans and features.
          </p>
          <Button variant="outline" size="lg">
            Contact Sales
          </Button>
        </motion.div>
      </main>
    </div>
  )
}
