import { NextRequest, NextResponse } from 'next/server'
import { generateText } from 'ai'
import { anthropic } from '@ai-sdk/anthropic'
import { GENERATION_PROMPTS, parseGeneratedContent, generateId } from '@/lib/claude'
import type { StudyItemType, StudyItem } from '@/lib/types'

export async function POST(request: NextRequest) {
  try {
    const { content, type, title } = await request.json() as {
      content: string
      type: StudyItemType
      title?: string
    }

    if (!content || !type) {
      return NextResponse.json(
        { success: false, error: 'Content and type are required' },
        { status: 400 }
      )
    }

    const prompt = GENERATION_PROMPTS[type]
    if (!prompt) {
      return NextResponse.json(
        { success: false, error: 'Invalid generation type' },
        { status: 400 }
      )
    }

    const { text } = await generateText({
      model: anthropic('claude-sonnet-4-20250514'),
      system: 'You are an educational content generator. Always respond with valid JSON only, no additional text or explanations.',
      prompt: `${prompt}\n\nContent to process:\n${content}`,
    })

    const parsedContent = parseGeneratedContent(type, text)

    const studyItem: StudyItem = {
      id: generateId(),
      title: title || `${type.charAt(0).toUpperCase() + type.slice(1)} - ${new Date().toLocaleDateString()}`,
      type,
      content: parsedContent,
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json({ success: true, data: studyItem })
  } catch (error) {
    console.error('Generation error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to generate content' },
      { status: 500 }
    )
  }
}
