'use client'

import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { motion } from 'framer-motion'
import { Plus, Sparkles, FolderOpen } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { StudyCard } from '@/components/dashboard/study-card'
import { useStudyStore } from '@/store/useStudyStore'
import type { StudyItemType } from '@/lib/types'

export default function DashboardPage() {
  const searchParams = useSearchParams()
  const filter = searchParams.get('filter') as StudyItemType | null
  const { items, searchQuery } = useStudyStore()

  // Filter items
  let filteredItems = items
  if (filter) {
    filteredItems = items.filter(item => item.type === filter)
  }
  if (searchQuery) {
    filteredItems = filteredItems.filter(item => 
      item.title.toLowerCase().includes(searchQuery.toLowerCase())
    )
  }

  const filterLabels: Record<string, string> = {
    mindmap: 'Mind Maps',
    flashcard: 'Flashcards',
    quiz: 'Quizzes',
    summary: 'Summaries',
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            {filter ? filterLabels[filter] : 'Your Study Materials'}
          </h1>
          <p className="text-muted-foreground mt-1">
            {filteredItems.length} {filteredItems.length === 1 ? 'item' : 'items'}
          </p>
        </div>
        <Link href="/create">
          <Button className="bg-primary hover:bg-primary/90 gap-2">
            <Plus className="w-4 h-4" />
            Create New
          </Button>
        </Link>
      </div>

      {/* Content */}
      {filteredItems.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-20 text-center"
        >
          <div className="w-20 h-20 rounded-2xl bg-muted flex items-center justify-center mb-6">
            <FolderOpen className="w-10 h-10 text-muted-foreground" />
          </div>
          <h2 className="text-xl font-semibold text-foreground mb-2">
            {searchQuery ? 'No results found' : 'No study materials yet'}
          </h2>
          <p className="text-muted-foreground max-w-sm mb-6">
            {searchQuery 
              ? 'Try a different search term'
              : 'Create your first study material by uploading content and letting AI do the magic.'
            }
          </p>
          {!searchQuery && (
            <Link href="/create">
              <Button className="bg-primary hover:bg-primary/90 gap-2">
                <Sparkles className="w-4 h-4" />
                Create with AI
              </Button>
            </Link>
          )}
        </motion.div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredItems.map((item, index) => (
            <StudyCard key={item.id} item={item} index={index} />
          ))}
        </div>
      )}
    </div>
  )
}
