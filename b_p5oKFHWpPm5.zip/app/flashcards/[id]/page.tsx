'use client'

import { useState, useCallback, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowLeft, ChevronLeft, ChevronRight, Shuffle, Check, RotateCcw, BookOpen } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { useStudyStore } from '@/store/useStudyStore'
import type { Flashcard } from '@/lib/types'

export default function FlashcardsPage() {
  const params = useParams()
  const { getItemById, updateItem } = useStudyStore()
  
  const item = getItemById(params.id as string)
  const [cards, setCards] = useState<Flashcard[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isFlipped, setIsFlipped] = useState(false)
  const [knownCount, setKnownCount] = useState(0)

  useEffect(() => {
    if (item?.content && Array.isArray(item.content)) {
      setCards(item.content as Flashcard[])
      setKnownCount((item.content as Flashcard[]).filter(c => c.known).length)
    }
  }, [item])

  const currentCard = cards[currentIndex]
  const progress = cards.length > 0 ? ((currentIndex + 1) / cards.length) * 100 : 0

  const handleFlip = useCallback(() => {
    setIsFlipped(prev => !prev)
  }, [])

  const handleNext = useCallback(() => {
    setIsFlipped(false)
    setCurrentIndex(prev => (prev + 1) % cards.length)
  }, [cards.length])

  const handlePrev = useCallback(() => {
    setIsFlipped(false)
    setCurrentIndex(prev => (prev - 1 + cards.length) % cards.length)
  }, [cards.length])

  const handleShuffle = useCallback(() => {
    const shuffled = [...cards].sort(() => Math.random() - 0.5)
    setCards(shuffled)
    setCurrentIndex(0)
    setIsFlipped(false)
  }, [cards])

  const handleMarkKnown = useCallback(() => {
    const updatedCards = cards.map((card, i) => 
      i === currentIndex ? { ...card, known: true } : card
    )
    setCards(updatedCards)
    setKnownCount(updatedCards.filter(c => c.known).length)
    updateItem(params.id as string, { content: updatedCards })
    handleNext()
  }, [cards, currentIndex, handleNext, params.id, updateItem])

  const handleStudyAgain = useCallback(() => {
    const updatedCards = cards.map((card, i) => 
      i === currentIndex ? { ...card, known: false } : card
    )
    setCards(updatedCards)
    setKnownCount(updatedCards.filter(c => c.known).length)
    updateItem(params.id as string, { content: updatedCards })
    handleNext()
  }, [cards, currentIndex, handleNext, params.id, updateItem])

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') handleNext()
      if (e.key === 'ArrowLeft') handlePrev()
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault()
        handleFlip()
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [handleNext, handlePrev, handleFlip])

  if (!item || cards.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Flashcards not found</h1>
          <p className="text-muted-foreground mb-4">These flashcards may have been deleted</p>
          <Link href="/dashboard">
            <Button>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="font-semibold text-foreground">{item.title}</h1>
              <p className="text-sm text-muted-foreground">
                Card {currentIndex + 1} of {cards.length} • {knownCount} known
              </p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={handleShuffle} className="gap-2">
            <Shuffle className="w-4 h-4" />
            Shuffle
          </Button>
        </div>
        <Progress value={progress} className="h-1" />
      </motion.header>

      {/* Flashcard */}
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-80px)] p-4">
        <div className="w-full max-w-2xl perspective-1000">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${currentIndex}-${isFlipped}`}
              initial={{ rotateY: isFlipped ? -90 : 90, opacity: 0 }}
              animate={{ rotateY: 0, opacity: 1 }}
              exit={{ rotateY: isFlipped ? 90 : -90, opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={handleFlip}
              className="cursor-pointer"
            >
              <div className={`
                relative bg-card rounded-2xl border-2 p-8 min-h-[300px] flex flex-col items-center justify-center
                shadow-lg hover:shadow-xl transition-shadow
                ${isFlipped ? 'border-accent' : 'border-primary/30'}
                ${currentCard?.known ? 'bg-green-50 dark:bg-green-950/20' : ''}
              `}>
                {/* Badge */}
                <div className={`
                  absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-medium
                  ${isFlipped ? 'bg-accent/20 text-accent-foreground' : 'bg-primary/10 text-primary'}
                `}>
                  {isFlipped ? 'Answer' : 'Question'}
                </div>

                {currentCard?.known && (
                  <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}

                {/* Content */}
                <div className="text-center">
                  <BookOpen className={`w-12 h-12 mx-auto mb-6 ${isFlipped ? 'text-accent' : 'text-primary'}`} />
                  <p className="text-xl md:text-2xl font-medium text-foreground text-pretty">
                    {isFlipped ? currentCard?.answer : currentCard?.question}
                  </p>
                </div>

                <p className="absolute bottom-4 text-sm text-muted-foreground">
                  Click to flip
                </p>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
          <Button variant="outline" size="lg" onClick={handlePrev} className="gap-2">
            <ChevronLeft className="w-5 h-5" />
            Previous
          </Button>

          <Button
            variant="outline"
            size="lg"
            onClick={handleStudyAgain}
            className="gap-2 border-orange-500 text-orange-500 hover:bg-orange-50 dark:hover:bg-orange-950/20"
          >
            <RotateCcw className="w-5 h-5" />
            Study Again
          </Button>

          <Button
            size="lg"
            onClick={handleMarkKnown}
            className="gap-2 bg-green-600 hover:bg-green-700"
          >
            <Check className="w-5 h-5" />
            Mark as Known
          </Button>

          <Button variant="outline" size="lg" onClick={handleNext} className="gap-2">
            Next
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>

        <p className="text-sm text-muted-foreground mt-6">
          Use arrow keys to navigate, space to flip
        </p>
      </div>
    </div>
  )
}
