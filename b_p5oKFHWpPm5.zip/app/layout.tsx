import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from 'sonner'
import { ThemeProvider } from '@/components/theme-provider'
import './globals.css'

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
})

export const metadata: Metadata = {
  title: 'LearnAI - AI-Powered Study Platform',
  description: 'Transform any content into mind maps, flashcards, quizzes, and summaries with AI. Study smarter, not harder.',
  keywords: ['AI', 'education', 'study', 'mind maps', 'flashcards', 'quizzes', 'learning'],
  authors: [{ name: 'LearnAI' }],
  openGraph: {
    title: 'LearnAI - AI-Powered Study Platform',
    description: 'Transform any content into mind maps, flashcards, quizzes, and summaries with AI.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#6C3EF4' },
    { media: '(prefers-color-scheme: dark)', color: '#7C4DFF' },
  ],
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster richColors position="top-right" />
        </ThemeProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
