'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowLeft, Check, X, RotateCcw, Trophy, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { useStudyStore } from '@/store/useStudyStore'
import type { QuizQuestion } from '@/lib/types'

export default function QuizPage() {
  const params = useParams()
  const { getItemById } = useStudyStore()
  
  const item = getItemById(params.id as string)
  const [questions, setQuestions] = useState<QuizQuestion[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [openAnswer, setOpenAnswer] = useState('')
  const [isAnswered, setIsAnswered] = useState(false)
  const [score, setScore] = useState(0)
  const [isComplete, setIsComplete] = useState(false)
  const [answers, setAnswers] = useState<(string | null)[]>([])

  useEffect(() => {
    if (item?.content && Array.isArray(item.content)) {
      const quizQuestions = item.content as QuizQuestion[]
      setQuestions(quizQuestions)
      setAnswers(new Array(quizQuestions.length).fill(null))
    }
  }, [item])

  const currentQuestion = questions[currentIndex]
  const progress = questions.length > 0 ? ((currentIndex + 1) / questions.length) * 100 : 0

  const handleSelectAnswer = (answer: string) => {
    if (isAnswered) return
    setSelectedAnswer(answer)
  }

  const handleSubmitAnswer = () => {
    if (!currentQuestion) return
    
    const answer = currentQuestion.type === 'open' ? openAnswer : selectedAnswer
    if (!answer) return

    setIsAnswered(true)
    
    const newAnswers = [...answers]
    newAnswers[currentIndex] = answer
    setAnswers(newAnswers)

    const isCorrect = currentQuestion.type === 'open'
      ? answer.toLowerCase().includes(currentQuestion.correctAnswer.toLowerCase())
      : answer === currentQuestion.correctAnswer

    if (isCorrect) {
      setScore(prev => prev + 1)
    }
  }

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1)
      setSelectedAnswer(null)
      setOpenAnswer('')
      setIsAnswered(false)
    } else {
      setIsComplete(true)
    }
  }

  const handleRestart = () => {
    setCurrentIndex(0)
    setSelectedAnswer(null)
    setOpenAnswer('')
    setIsAnswered(false)
    setScore(0)
    setIsComplete(false)
    setAnswers(new Array(questions.length).fill(null))
  }

  const isCorrect = (option: string) => {
    return isAnswered && option === currentQuestion?.correctAnswer
  }

  const isWrong = (option: string) => {
    return isAnswered && option === selectedAnswer && option !== currentQuestion?.correctAnswer
  }

  if (!item || questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Quiz not found</h1>
          <p className="text-muted-foreground mb-4">This quiz may have been deleted</p>
          <Link href="/dashboard">
            <Button>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    )
  }

  if (isComplete) {
    const percentage = Math.round((score / questions.length) * 100)
    
    return (
      <div className="min-h-screen bg-background">
        <motion.header
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border"
        >
          <div className="flex items-center h-16 px-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="font-semibold text-foreground ml-4">{item.title}</h1>
          </div>
        </motion.header>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center justify-center min-h-[calc(100vh-80px)] p-4"
        >
          <div className="bg-card rounded-2xl border border-border p-8 max-w-md w-full text-center">
            <div className={cn(
              'w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center',
              percentage >= 70 ? 'bg-green-100 dark:bg-green-900/30' : 'bg-orange-100 dark:bg-orange-900/30'
            )}>
              <Trophy className={cn(
                'w-10 h-10',
                percentage >= 70 ? 'text-green-600' : 'text-orange-600'
              )} />
            </div>

            <h2 className="text-2xl font-bold text-foreground mb-2">Quiz Complete!</h2>
            <p className="text-muted-foreground mb-6">Here are your results</p>

            <div className="text-5xl font-bold text-foreground mb-2">{percentage}%</div>
            <p className="text-muted-foreground mb-8">
              {score} out of {questions.length} correct
            </p>

            <div className="flex flex-col gap-3">
              <Button onClick={handleRestart} className="w-full gap-2">
                <RotateCcw className="w-4 h-4" />
                Try Again
              </Button>
              <Link href="/dashboard" className="w-full">
                <Button variant="outline" className="w-full">
                  Back to Dashboard
                </Button>
              </Link>
            </div>
          </div>

          {/* Review answers */}
          <div className="mt-8 w-full max-w-2xl">
            <h3 className="font-semibold text-foreground mb-4">Review your answers</h3>
            <div className="space-y-3">
              {questions.map((q, i) => {
                const userAnswer = answers[i]
                const correct = q.type === 'open'
                  ? userAnswer?.toLowerCase().includes(q.correctAnswer.toLowerCase())
                  : userAnswer === q.correctAnswer
                
                return (
                  <div key={q.id} className={cn(
                    'p-4 rounded-xl border',
                    correct ? 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800' : 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800'
                  )}>
                    <div className="flex items-start gap-3">
                      <div className={cn(
                        'w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5',
                        correct ? 'bg-green-500' : 'bg-red-500'
                      )}>
                        {correct ? <Check className="w-4 h-4 text-white" /> : <X className="w-4 h-4 text-white" />}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{q.question}</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          Your answer: {userAnswer || 'Not answered'}
                        </p>
                        {!correct && (
                          <p className="text-sm text-green-600 dark:text-green-400 mt-1">
                            Correct: {q.correctAnswer}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="font-semibold text-foreground">{item.title}</h1>
              <p className="text-sm text-muted-foreground">
                Question {currentIndex + 1} of {questions.length}
              </p>
            </div>
          </div>
          <div className="text-sm font-medium text-primary">
            Score: {score}
          </div>
        </div>
        <Progress value={progress} className="h-1" />
      </motion.header>

      {/* Question */}
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-80px)] p-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="w-full max-w-2xl"
          >
            <div className="bg-card rounded-2xl border border-border p-6 md:p-8">
              {/* Question type badge */}
              <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-4">
                {currentQuestion?.type === 'mcq' && 'Multiple Choice'}
                {currentQuestion?.type === 'truefalse' && 'True / False'}
                {currentQuestion?.type === 'open' && 'Open Ended'}
              </div>

              {/* Question */}
              <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-6">
                {currentQuestion?.question}
              </h2>

              {/* Answer options */}
              {currentQuestion?.type === 'open' ? (
                <div className="space-y-4">
                  <Input
                    placeholder="Type your answer..."
                    value={openAnswer}
                    onChange={(e) => setOpenAnswer(e.target.value)}
                    disabled={isAnswered}
                    className="text-lg py-6"
                  />
                  {isAnswered && (
                    <div className={cn(
                      'p-4 rounded-xl',
                      openAnswer.toLowerCase().includes(currentQuestion.correctAnswer.toLowerCase())
                        ? 'bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800'
                        : 'bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800'
                    )}>
                      <p className="text-sm font-medium text-foreground">
                        Expected answer: {currentQuestion.correctAnswer}
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="grid gap-3">
                  {currentQuestion?.options?.map((option, i) => (
                    <button
                      key={i}
                      onClick={() => handleSelectAnswer(option)}
                      disabled={isAnswered}
                      className={cn(
                        'w-full p-4 rounded-xl border-2 text-left transition-all',
                        'hover:border-primary/50 hover:bg-primary/5',
                        selectedAnswer === option && !isAnswered && 'border-primary bg-primary/5',
                        isCorrect(option) && 'border-green-500 bg-green-50 dark:bg-green-950/20',
                        isWrong(option) && 'border-red-500 bg-red-50 dark:bg-red-950/20',
                        !selectedAnswer && !isAnswered && 'border-border'
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          'w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium shrink-0',
                          selectedAnswer === option && !isAnswered && 'bg-primary text-primary-foreground',
                          isCorrect(option) && 'bg-green-500 text-white',
                          isWrong(option) && 'bg-red-500 text-white',
                          !selectedAnswer && !isAnswered && 'bg-muted text-muted-foreground',
                          selectedAnswer !== option && !isCorrect(option) && !isWrong(option) && isAnswered && 'bg-muted text-muted-foreground'
                        )}>
                          {isCorrect(option) ? <Check className="w-4 h-4" /> : isWrong(option) ? <X className="w-4 h-4" /> : String.fromCharCode(65 + i)}
                        </div>
                        <span className="text-foreground">{option}</span>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 mt-6">
              {!isAnswered ? (
                <Button
                  onClick={handleSubmitAnswer}
                  disabled={!selectedAnswer && !openAnswer}
                  className="bg-primary hover:bg-primary/90"
                >
                  Submit Answer
                </Button>
              ) : (
                <Button onClick={handleNext} className="gap-2 bg-primary hover:bg-primary/90">
                  {currentIndex < questions.length - 1 ? (
                    <>
                      Next Question
                      <ChevronRight className="w-4 h-4" />
                    </>
                  ) : (
                    'See Results'
                  )}
                </Button>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  )
}
