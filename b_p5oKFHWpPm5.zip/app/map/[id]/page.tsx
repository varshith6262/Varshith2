'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  ReactFlow,
  Node,
  Edge,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  MarkerType,
  BackgroundVariant,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { motion } from 'framer-motion'
import { ArrowLeft, Download, Maximize2, Minimize2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useStudyStore } from '@/store/useStudyStore'
import type { MindMapData, MindMapNode } from '@/lib/types'

function flattenMindMap(
  node: MindMapNode,
  parentId: string | null = null,
  level: number = 0,
  index: number = 0,
  totalSiblings: number = 1
): { nodes: Node[]; edges: Edge[] } {
  const nodes: Node[] = []
  const edges: Edge[] = []

  // Calculate position based on level and index
  const xSpacing = 300
  const ySpacing = 100
  const xPos = level * xSpacing
  const yOffset = (index - (totalSiblings - 1) / 2) * ySpacing * (level === 0 ? 0 : 1)

  const nodeData: Node = {
    id: node.id,
    type: 'default',
    position: { x: xPos, y: yOffset },
    data: { label: node.label },
    style: {
      background: level === 0 ? 'hsl(var(--primary))' : 'hsl(var(--card))',
      color: level === 0 ? 'hsl(var(--primary-foreground))' : 'hsl(var(--card-foreground))',
      border: `2px solid ${level === 0 ? 'hsl(var(--primary))' : 'hsl(var(--border))'}`,
      borderRadius: '12px',
      padding: '12px 20px',
      fontSize: level === 0 ? '16px' : '14px',
      fontWeight: level === 0 ? '600' : '500',
      minWidth: '120px',
      textAlign: 'center' as const,
    },
  }
  nodes.push(nodeData)

  if (parentId) {
    edges.push({
      id: `${parentId}-${node.id}`,
      source: parentId,
      target: node.id,
      type: 'smoothstep',
      animated: false,
      style: { stroke: 'hsl(var(--border))', strokeWidth: 2 },
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: 'hsl(var(--border))',
      },
    })
  }

  if (node.children && node.children.length > 0) {
    node.children.forEach((child, i) => {
      const childResult = flattenMindMap(child, node.id, level + 1, i, node.children!.length)
      nodes.push(...childResult.nodes)
      edges.push(...childResult.edges)
    })
  }

  return { nodes, edges }
}

export default function MindMapPage() {
  const params = useParams()
  const router = useRouter()
  const { getItemById } = useStudyStore()
  const [isFullscreen, setIsFullscreen] = useState(false)
  
  const item = getItemById(params.id as string)
  const mindMapData = item?.content as MindMapData | undefined

  const { initialNodes, initialEdges } = useMemo(() => {
    if (!mindMapData?.central) {
      return { initialNodes: [], initialEdges: [] }
    }
    return flattenMindMap(mindMapData.central)
  }, [mindMapData])

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)

  useEffect(() => {
    if (initialNodes.length > 0) {
      setNodes(initialNodes)
      setEdges(initialEdges)
    }
  }, [initialNodes, initialEdges, setNodes, setEdges])

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }, [])

  if (!item) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Mind Map not found</h1>
          <p className="text-muted-foreground mb-4">This mind map may have been deleted</p>
          <Link href="/dashboard">
            <Button>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="font-semibold text-foreground">{item.title}</h1>
              <p className="text-sm text-muted-foreground">Mind Map</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="w-4 h-4" />
              Export
            </Button>
            <Button variant="outline" size="icon" onClick={toggleFullscreen}>
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </motion.header>

      {/* Mind Map */}
      <div className="h-[calc(100vh-64px)]">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          fitView
          fitViewOptions={{ padding: 0.5 }}
          minZoom={0.1}
          maxZoom={2}
        >
          <Background variant={BackgroundVariant.Dots} gap={20} size={1} />
          <Controls />
        </ReactFlow>
      </div>
    </div>
  )
}
