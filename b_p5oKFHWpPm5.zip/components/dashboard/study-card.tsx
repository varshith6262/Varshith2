'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { Brain, BookOpen, FileQuestion, FileText, Trash2, MoreVertical } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import type { StudyItem } from '@/lib/types'
import { useStudyStore } from '@/store/useStudyStore'
import { toast } from 'sonner'

const typeConfig = {
  mindmap: {
    icon: Brain,
    label: 'Mind Map',
    href: '/map',
    color: 'text-primary bg-primary/10',
  },
  flashcard: {
    icon: BookOpen,
    label: 'Flashcards',
    href: '/flashcards',
    color: 'text-accent-foreground bg-accent/20',
  },
  quiz: {
    icon: FileQuestion,
    label: 'Quiz',
    href: '/quiz',
    color: 'text-primary bg-primary/10',
  },
  summary: {
    icon: FileText,
    label: 'Summary',
    href: '/summary',
    color: 'text-accent-foreground bg-accent/20',
  },
}

interface StudyCardProps {
  item: StudyItem
  index: number
}

export function StudyCard({ item, index }: StudyCardProps) {
  const { removeItem } = useStudyStore()
  const config = typeConfig[item.type]
  const Icon = config.icon

  const handleDelete = () => {
    removeItem(item.id)
    toast.success('Item deleted')
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Link href={`${config.href}/${item.id}`}>
        <div className="group bg-card rounded-xl border border-border p-5 hover:border-primary/30 hover:shadow-lg transition-all duration-300 cursor-pointer">
          <div className="flex items-start justify-between mb-4">
            <div className={`w-12 h-12 rounded-xl ${config.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
              <Icon className="w-6 h-6" />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild onClick={(e) => e.preventDefault()}>
                <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  className="text-destructive"
                  onClick={(e) => {
                    e.preventDefault()
                    handleDelete()
                  }}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <h3 className="font-semibold text-foreground mb-1 truncate">{item.title}</h3>
          <p className="text-sm text-muted-foreground mb-3">{config.label}</p>
          
          <p className="text-xs text-muted-foreground">
            {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
          </p>
        </div>
      </Link>
    </motion.div>
  )
}
