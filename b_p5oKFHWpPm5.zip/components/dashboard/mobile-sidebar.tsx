'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Brain, Home, GitBranch, BookOpen, FileQuestion, LayoutTemplate, Settings, LogOut } from 'lucide-react'
import { cn } from '@/lib/utils'
import { SheetHeader, SheetTitle } from '@/components/ui/sheet'

const navItems = [
  { href: '/dashboard', icon: Home, label: 'Home' },
  { href: '/dashboard?filter=mindmap', icon: GitBranch, label: 'My Maps' },
  { href: '/dashboard?filter=flashcard', icon: BookOpen, label: 'Flashcards' },
  { href: '/dashboard?filter=quiz', icon: FileQuestion, label: 'Quizzes' },
  { href: '/templates', icon: LayoutTemplate, label: 'Templates' },
]

export function MobileSidebar() {
  const pathname = usePathname()

  return (
    <div className="flex flex-col h-full bg-card">
      {/* Logo */}
      <SheetHeader className="p-6 border-b border-border">
        <SheetTitle asChild>
          <Link href="/" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
              <Brain className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-xl text-foreground">LearnAI</span>
          </Link>
        </SheetTitle>
      </SheetHeader>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-1">
          {navItems.map((item) => {
            const isActive = pathname === item.href
            
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    'flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-primary/10 text-primary'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Bottom section */}
      <div className="p-4 border-t border-border">
        <ul className="space-y-1">
          <li>
            <Link
              href="/settings"
              className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              <Settings className="w-5 h-5" />
              Settings
            </Link>
          </li>
          <li>
            <Link
              href="/"
              className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              <LogOut className="w-5 h-5" />
              Log out
            </Link>
          </li>
        </ul>
      </div>
    </div>
  )
}
