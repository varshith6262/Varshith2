'use client'

import { motion } from 'framer-motion'
import { Brain, BookOpen, FileQuestion, FileText } from 'lucide-react'

const features = [
  {
    icon: Brain,
    title: 'Mind Maps',
    description: 'Visualize complex topics with AI-generated mind maps that help you understand connections between concepts.',
    color: 'bg-primary/10 text-primary',
  },
  {
    icon: BookOpen,
    title: 'Flashcards',
    description: 'Create interactive flashcards automatically from any content. Perfect for memorization and quick reviews.',
    color: 'bg-accent/20 text-accent-foreground',
  },
  {
    icon: FileQuestion,
    title: 'Quizzes',
    description: 'Test your knowledge with AI-generated quizzes featuring multiple choice, true/false, and open-ended questions.',
    color: 'bg-primary/10 text-primary',
  },
  {
    icon: FileText,
    title: 'Summaries',
    description: 'Get concise bullet-point summaries that capture the key information from lengthy texts.',
    color: 'bg-accent/20 text-accent-foreground',
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
}

export function Features() {
  return (
    <section id="features" className="py-20 px-4 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Powerful Study Tools
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Transform any content into effective study materials with our AI-powered tools
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {features.map((feature) => (
            <motion.div
              key={feature.title}
              variants={itemVariants}
              className="group bg-card rounded-xl border border-border p-6 hover:border-primary/30 hover:shadow-lg transition-all duration-300"
            >
              <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
