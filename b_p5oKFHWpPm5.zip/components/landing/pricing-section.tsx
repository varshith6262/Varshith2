'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { cn } from '@/lib/utils'

const plans = [
  {
    name: 'Free',
    price: 0,
    annualPrice: 0,
    description: 'Perfect for trying out LearnAI',
    features: [
      '50 AI generations per month',
      'Basic mind maps',
      'Flashcard creation',
      'Simple quizzes',
      'Community support',
    ],
    credits: 50,
    cta: 'Get Started',
    highlighted: false,
  },
  {
    name: 'Basic',
    price: 9,
    annualPrice: 7,
    description: 'Great for regular students',
    features: [
      '500 AI generations per month',
      'Advanced mind maps',
      'Unlimited flashcards',
      'All quiz types',
      'Export to PDF',
      'Email support',
    ],
    credits: 500,
    cta: 'Start Basic',
    highlighted: false,
  },
  {
    name: 'Pro',
    price: 19,
    annualPrice: 15,
    description: 'Best for power users',
    features: [
      'Unlimited AI generations',
      'Premium mind maps',
      'Unlimited flashcards',
      'All quiz types',
      'Export to all formats',
      'Priority support',
      'Team collaboration',
      'API access',
    ],
    credits: 'unlimited',
    cta: 'Start Pro',
    highlighted: true,
  },
]

export function PricingSection() {
  const [isAnnual, setIsAnnual] = useState(false)

  return (
    <section id="pricing" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Choose the plan that fits your learning needs
          </p>

          {/* Toggle */}
          <div className="flex items-center justify-center gap-3">
            <span className={cn('text-sm', !isAnnual ? 'text-foreground font-medium' : 'text-muted-foreground')}>
              Monthly
            </span>
            <Switch checked={isAnnual} onCheckedChange={setIsAnnual} />
            <span className={cn('text-sm', isAnnual ? 'text-foreground font-medium' : 'text-muted-foreground')}>
              Annual
              <span className="ml-1.5 text-xs text-primary font-medium">Save 20%</span>
            </span>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 items-start">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={cn(
                'relative bg-card rounded-xl border p-6',
                plan.highlighted
                  ? 'border-primary shadow-lg shadow-primary/10 scale-105'
                  : 'border-border'
              )}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                  Most Popular
                </div>
              )}

              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-foreground mb-2">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
                <div className="flex items-end justify-center gap-1">
                  <span className="text-4xl font-bold text-foreground">
                    ${isAnnual ? plan.annualPrice : plan.price}
                  </span>
                  <span className="text-muted-foreground mb-1">/mo</span>
                </div>
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span className="text-sm text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link href="/register" className="block">
                <Button
                  className={cn(
                    'w-full',
                    plan.highlighted
                      ? 'bg-primary hover:bg-primary/90'
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                  )}
                >
                  {plan.cta}
                </Button>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
