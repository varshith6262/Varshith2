'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { ArrowRight, Play, Sparkles, Brain, BookOpen, FileQuestion } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Hero() {
  return (
    <section className="relative pt-32 pb-20 px-4 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-primary/20 rounded-full blur-[120px] opacity-50" />
        <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-accent/20 rounded-full blur-[100px] opacity-40" />
      </div>

      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center lg:text-left"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">AI-Powered Learning</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
              Transform Any Content Into{' '}
              <span className="text-primary">Study Materials</span>
            </h1>

            <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0 text-pretty">
              Upload your notes, articles, or any text and let AI create mind maps, flashcards, 
              quizzes, and summaries. Study smarter, not harder.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/register">
                <Button size="lg" className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
                  Try for Free
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link href="#how-it-works">
                <Button size="lg" variant="outline" className="w-full sm:w-auto gap-2">
                  <Play className="w-4 h-4" />
                  See How It Works
                </Button>
              </Link>
            </div>

            <div className="mt-10 flex items-center gap-6 justify-center lg:justify-start text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>No credit card required</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>50 free credits</span>
              </div>
            </div>
          </motion.div>

          {/* Right content - Demo Preview */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative"
          >
            <div className="relative bg-card rounded-2xl border border-border shadow-2xl overflow-hidden">
              {/* Browser bar */}
              <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-muted/50">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-yellow-400" />
                  <div className="w-3 h-3 rounded-full bg-green-400" />
                </div>
                <div className="flex-1 text-center text-xs text-muted-foreground">
                  learnai.app/dashboard
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-foreground">Your Study Materials</h3>
                  <Button size="sm" className="bg-primary hover:bg-primary/90 text-xs">
                    + Create New
                  </Button>
                </div>

                {/* Study cards */}
                <div className="grid grid-cols-2 gap-3">
                  <DemoCard
                    icon={<Brain className="w-5 h-5 text-primary" />}
                    title="Biology Mind Map"
                    type="Mind Map"
                    delay={0.3}
                  />
                  <DemoCard
                    icon={<BookOpen className="w-5 h-5 text-accent" />}
                    title="History Flashcards"
                    type="Flashcards"
                    delay={0.4}
                  />
                  <DemoCard
                    icon={<FileQuestion className="w-5 h-5 text-primary" />}
                    title="Math Quiz"
                    type="Quiz"
                    delay={0.5}
                  />
                  <DemoCard
                    icon={<Sparkles className="w-5 h-5 text-accent" />}
                    title="Physics Summary"
                    type="Summary"
                    delay={0.6}
                  />
                </div>
              </div>
            </div>

            {/* Floating elements */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.7 }}
              className="absolute -left-4 top-1/4 bg-card rounded-lg border border-border shadow-lg p-3 hidden lg:block"
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-green-600 dark:text-green-400" />
                </div>
                <div className="text-xs">
                  <p className="font-medium text-foreground">AI Generated</p>
                  <p className="text-muted-foreground">in 3 seconds</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

function DemoCard({
  icon,
  title,
  type,
  delay,
}: {
  icon: React.ReactNode
  title: string
  type: string
  delay: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
      className="bg-muted/50 rounded-lg p-3 border border-border hover:border-primary/30 transition-colors cursor-pointer"
    >
      <div className="w-10 h-10 rounded-lg bg-background flex items-center justify-center mb-2">
        {icon}
      </div>
      <p className="font-medium text-sm text-foreground truncate">{title}</p>
      <p className="text-xs text-muted-foreground">{type}</p>
    </motion.div>
  )
}
