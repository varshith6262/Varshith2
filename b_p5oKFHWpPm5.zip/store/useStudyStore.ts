'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { StudyItem, User, StudyItemType } from '@/lib/types'

interface StudyState {
  // Study items
  items: StudyItem[]
  addItem: (item: StudyItem) => void
  removeItem: (id: string) => void
  updateItem: (id: string, updates: Partial<StudyItem>) => void
  getItemById: (id: string) => StudyItem | undefined
  getItemsByType: (type: StudyItemType) => StudyItem[]
  
  // User state
  user: User | null
  setUser: (user: User | null) => void
  decrementCredits: () => void
  
  // UI state
  isGenerating: boolean
  setIsGenerating: (value: boolean) => void
  
  // Search
  searchQuery: string
  setSearchQuery: (query: string) => void
}

const defaultUser: User = {
  id: '1',
  name: 'Demo User',
  email: 'demo@learnai.com',
  credits: 50,
}

export const useStudyStore = create<StudyState>()(
  persist(
    (set, get) => ({
      // Study items
      items: [],
      addItem: (item) =>
        set((state) => ({ items: [item, ...state.items] })),
      removeItem: (id) =>
        set((state) => ({ items: state.items.filter((item) => item.id !== id) })),
      updateItem: (id, updates) =>
        set((state) => ({
          items: state.items.map((item) =>
            item.id === id ? { ...item, ...updates, updatedAt: new Date().toISOString() } : item
          ),
        })),
      getItemById: (id) => get().items.find((item) => item.id === id),
      getItemsByType: (type) => get().items.filter((item) => item.type === type),
      
      // User state
      user: defaultUser,
      setUser: (user) => set({ user }),
      decrementCredits: () =>
        set((state) => ({
          user: state.user
            ? { ...state.user, credits: Math.max(0, state.user.credits - 1) }
            : null,
        })),
      
      // UI state
      isGenerating: false,
      setIsGenerating: (value) => set({ isGenerating: value }),
      
      // Search
      searchQuery: '',
      setSearchQuery: (query) => set({ searchQuery: query }),
    }),
    {
      name: 'learnai-storage',
      partialize: (state) => ({
        items: state.items,
        user: state.user,
      }),
    }
  )
)
