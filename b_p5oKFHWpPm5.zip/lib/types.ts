// Study item types
export type StudyItemType = 'mindmap' | 'flashcard' | 'quiz' | 'summary'

export interface StudyItem {
  id: string
  title: string
  type: StudyItemType
  content: MindMapData | Flashcard[] | QuizQuestion[] | string[]
  createdAt: string
  updatedAt?: string
}

// Mind Map types
export interface MindMapNode {
  id: string
  label: string
  children?: MindMapNode[]
}

export interface MindMapData {
  central: MindMapNode
}

// Flashcard types
export interface Flashcard {
  id: string
  question: string
  answer: string
  known?: boolean
}

// Quiz types
export type QuizQuestionType = 'mcq' | 'truefalse' | 'open'

export interface QuizQuestion {
  id: string
  type: QuizQuestionType
  question: string
  options?: string[]
  correctAnswer: string
  userAnswer?: string
}

export interface QuizResult {
  totalQuestions: number
  correctAnswers: number
  percentage: number
  questions: QuizQuestion[]
}

// Template types
export interface Template {
  id: string
  title: string
  subject: string
  description: string
  type: StudyItemType
  previewImage?: string
}

// User types
export interface User {
  id: string
  name: string
  email: string
  avatar?: string
  credits: number
}

// Pricing types
export interface PricingTier {
  id: string
  name: string
  price: number
  annualPrice: number
  features: string[]
  highlighted?: boolean
  credits: number | 'unlimited'
}

// Generation request/response types
export interface GenerateRequest {
  content: string
  type: StudyItemType
  title?: string
}

export interface GenerateResponse {
  success: boolean
  data?: StudyItem
  error?: string
}
