import type { StudyItemType, MindMapData, Flashcard, QuizQuestion } from './types'

export const GENERATION_PROMPTS = {
  mindmap: `Read this content and return a JSON mind map with the following structure:
{
  "central": {
    "id": "root",
    "label": "Main Topic",
    "children": [
      {
        "id": "branch1",
        "label": "Branch 1",
        "children": [
          { "id": "sub1", "label": "Sub-topic 1" },
          { "id": "sub2", "label": "Sub-topic 2" },
          { "id": "sub3", "label": "Sub-topic 3" }
        ]
      }
    ]
  }
}
Create up to 5 main branches, each with up to 3 sub-nodes. Only return valid JSON, no other text.`,

  flashcard: `Create 10 flashcards from this content as a JSON array with the following structure:
[
  { "id": "1", "question": "Question text here", "answer": "Answer text here" },
  { "id": "2", "question": "Question text here", "answer": "Answer text here" }
]
Make the questions clear and the answers concise. Only return valid JSON, no other text.`,

  quiz: `Create 5 quiz questions from this content as a JSON array. Include different types:
[
  { "id": "1", "type": "mcq", "question": "Question?", "options": ["A", "B", "C", "D"], "correctAnswer": "A" },
  { "id": "2", "type": "truefalse", "question": "Statement?", "options": ["True", "False"], "correctAnswer": "True" },
  { "id": "3", "type": "open", "question": "Question?", "correctAnswer": "Expected answer" }
]
Mix question types and ensure answers are accurate. Only return valid JSON, no other text.`,

  summary: `Summarize this content into 5 clear bullet points for a student. Return as a JSON array of strings:
["Point 1", "Point 2", "Point 3", "Point 4", "Point 5"]
Make each point concise and informative. Only return valid JSON, no other text.`,
}

export function parseGeneratedContent(
  type: StudyItemType,
  rawContent: string
): MindMapData | Flashcard[] | QuizQuestion[] | string[] {
  try {
    // Extract JSON from the response (handle markdown code blocks)
    let jsonStr = rawContent
    const jsonMatch = rawContent.match(/```(?:json)?\s*([\s\S]*?)\s*```/)
    if (jsonMatch) {
      jsonStr = jsonMatch[1]
    }
    
    const parsed = JSON.parse(jsonStr.trim())
    
    switch (type) {
      case 'mindmap':
        return parsed as MindMapData
      case 'flashcard':
        return (parsed as Flashcard[]).map((card, i) => ({
          ...card,
          id: card.id || String(i + 1),
          known: false,
        }))
      case 'quiz':
        return (parsed as QuizQuestion[]).map((q, i) => ({
          ...q,
          id: q.id || String(i + 1),
        }))
      case 'summary':
        return parsed as string[]
      default:
        throw new Error('Invalid type')
    }
  } catch {
    throw new Error('Failed to parse AI response')
  }
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}
